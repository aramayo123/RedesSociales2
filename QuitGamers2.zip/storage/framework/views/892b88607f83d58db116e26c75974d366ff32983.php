<?php echo e($slot); ?>

<?php /**PATH F:\wamp64\www\QuitGamers2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>