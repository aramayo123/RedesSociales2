# Privacy Policy


editar este archivo de politicas en resources/markdouwn/
